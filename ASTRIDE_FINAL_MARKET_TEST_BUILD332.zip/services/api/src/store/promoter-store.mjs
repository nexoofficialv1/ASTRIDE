import crypto from 'node:crypto';
const promoters=new Map(),links=new Map(),coaching=[],earnings=[],sessions=new Map(),withdrawals=[];
const clone=x=>structuredClone(x),now=()=>new Date().toISOString();
const hashPassword=(value,salt=crypto.randomBytes(16).toString('hex'))=>({salt,hash:crypto.scryptSync(String(value),salt,64).toString('hex')});
const verifyPassword=(value,record)=>{if(!record?.salt||!record?.hash)return false;const candidate=crypto.scryptSync(String(value),record.salt,64);return crypto.timingSafeEqual(candidate,Buffer.from(record.hash,'hex'));};
export function upsertPromoter(p){
 const previous=p.id?promoters.get(p.id):null;
 const credential=p.password
   ?hashPassword(p.password)
   :previous?.credential||null;
 const x={
   id:p.id||crypto.randomUUID(),
   role:String(p.role||previous?.role||'PROMOTER').toUpperCase(),
   status:String(p.status||previous?.status||'ACTIVE').toUpperCase(),
   areaPromoterId:p.areaPromoterId??previous?.areaPromoterId??null,
   areaId:p.areaId??previous?.areaId??null,
   mobile:p.mobile||previous?.mobile||null,
   name:p.name||previous?.name||'Partner',
   credential,
   createdAt:previous?.createdAt||now(),
   ...previous,
   ...p,
   updatedAt:now(),
 };
 x.role=String(x.role||'PROMOTER').toUpperCase();
 x.status=String(x.status||'ACTIVE').toUpperCase();
 delete x.password;
 promoters.set(x.id,x);
 return sanitize(x);
}
export function updatePromoterProfile(actorId,patch={}){
 const actor=promoters.get(actorId);
 if(!actor)return null;
 const safe={};
 for(const key of ['name','address','upiId','emergencyContact','preferredLanguage','photoUrl']){
   if(patch[key]!==undefined)safe[key]=patch[key];
 }
 if(patch.bank&&typeof patch.bank==='object'){
   safe.bank={
     accountHolder:String(patch.bank.accountHolder||'').trim(),
     accountNumber:String(patch.bank.accountNumber||'').trim(),
     ifsc:String(patch.bank.ifsc||'').trim().toUpperCase(),
   };
 }
 Object.assign(actor,safe,{id:actor.id,updatedAt:now()});
 promoters.set(actor.id,actor);
 return sanitize(actor);
}
export function partnerLogin({mobile,password}){const actor=[...promoters.values()].find(x=>x.mobile===mobile&&x.status==='ACTIVE');if(!actor||!verifyPassword(password,actor.credential))return null;const token=crypto.randomBytes(32).toString('hex');const session={token,actorId:actor.id,role:actor.role,expiresAt:new Date(Date.now()+12*60*60*1000).toISOString(),createdAt:now()};sessions.set(token,session);return {token,expiresAt:session.expiresAt,partner:sanitize(actor)};}
export function authenticatePartner(header){const token=String(header||'').replace(/^Bearer\s+/i,'');const s=sessions.get(token);if(!s||new Date(s.expiresAt)<=new Date()){if(token)sessions.delete(token);return null;}const actor=promoters.get(s.actorId);return actor&&actor.status==='ACTIVE'?sanitize(actor):null;}
export function partnerLogout(header){const token=String(header||'').replace(/^Bearer\s+/i,'');return sessions.delete(token);}
export function linkDriver({promoterId,areaPromoterId=null,driverId}){const x={id:crypto.randomUUID(),promoterId,areaPromoterId,driverId,createdAt:now()};links.set(driverId,x);return clone(x);}
export function getDriverPartnerLink(driverId){const x=links.get(driverId);return x?clone(x):null;}
export function getPromoter(actorId){const x=promoters.get(actorId);return x?sanitize(x):null;}

export function updatePromoterStatus(
 actorId,
 {status,reason=null,reviewedBy=null}={},
){
 const actor=promoters.get(actorId);
 if(!actor)return null;
 const normalized=String(status||'').toUpperCase();
 if(!['ACTIVE','SUSPENDED','TERMINATED'].includes(normalized)){
   throw new Error('invalid_partner_status');
 }
 if(actor.status==='TERMINATED'&&normalized!=='TERMINATED'){
   throw new Error('terminated_partner_cannot_be_reactivated');
 }
 if(
   ['SUSPENDED','TERMINATED'].includes(normalized) &&
   !String(reason||'').trim()
 ){
   throw new Error('status_change_reason_required');
 }
 const changedAt=now();
 actor.statusHistory=Array.isArray(actor.statusHistory)
   ?actor.statusHistory
   :[];
 actor.statusHistory.unshift({
   from:actor.status||'ACTIVE',
   to:normalized,
   reason:String(reason||'').trim()||null,
   reviewedBy,
   changedAt,
 });
 actor.status=normalized;
 actor.statusReason=String(reason||'').trim()||null;
 actor.statusChangedBy=reviewedBy;
 actor.statusChangedAt=changedAt;
 actor.updatedAt=changedAt;
 return sanitize(actor);
}

export function assignPromoterToArea(
 promoterId,
 {areaPromoterId,areaId=null,reason=null,reviewedBy=null}={},
){
 const promoter=promoters.get(promoterId);
 if(!promoter||promoter.role!=='PROMOTER')return null;
 const area=promoters.get(areaPromoterId);
 if(
   !area ||
   area.role!=='AREA_PROMOTER' ||
   area.status!=='ACTIVE'
 ){
   throw new Error('active_area_promoter_required');
 }
 const changedAt=now();
 promoter.assignmentHistory=Array.isArray(promoter.assignmentHistory)
   ?promoter.assignmentHistory
   :[];
 promoter.assignmentHistory.unshift({
   fromAreaPromoterId:promoter.areaPromoterId||null,
   toAreaPromoterId:area.id,
   reason:String(reason||'').trim()||null,
   reviewedBy,
   changedAt,
 });
 promoter.areaPromoterId=area.id;
 promoter.areaId=areaId||area.areaId||promoter.areaId||null;
 promoter.updatedAt=changedAt;
 return sanitize(promoter);
}

export function updateLinkedDriversArea(promoterId,areaPromoterId){
 const affected=[];
 for(const link of links.values()){
   if(link.promoterId!==promoterId)continue;
   link.areaPromoterId=areaPromoterId||null;
   link.updatedAt=now();
   affected.push(link.driverId);
 }
 return affected;
}
export function listPromoters(){return [...promoters.values()].map(sanitize);}
export function scopedDriverIds(actorId){const actor=promoters.get(actorId);if(!actor)return[];return [...links.values()].filter(x=>actor.role==='AREA_PROMOTER'?x.areaPromoterId===actorId:x.promoterId===actorId).map(x=>x.driverId);}
export function addCoachingLog(input){const x={id:crypto.randomUUID(),type:'COACHING',status:'SENT',createdAt:now(),...input};coaching.unshift(x);return clone(x);}
export function listCoachingLogs(actorId){return coaching.filter(x=>x.promoterId===actorId||x.areaPromoterId===actorId).map(clone);}
export function addPromoterEarning(input){const x={id:crypto.randomUUID(),status:'PENDING_MONTH_CLOSE',createdAt:now(),...input};earnings.unshift(x);return clone(x);}
export function earningsSummary(actorId,month){const rows=earnings.filter(x=>x.beneficiaryId===actorId&&(!month||x.month===month));return {amount:Number(rows.filter(x=>x.type!=='WITHDRAWAL').reduce((s,x)=>s+x.amount,0).toFixed(2)),withdrawable:Number(rows.filter(x=>x.status==='WITHDRAWABLE').reduce((s,x)=>s+x.amount,0).toFixed(2)),items:rows.map(clone),nextSettlementDate:nextMonthClose()};}
export function exportPromoterStoreState(){return{promoters:[...promoters.entries()],links:[...links.entries()],coaching:clone(coaching),earnings:clone(earnings),withdrawals:clone(withdrawals)}}
export function restorePromoterStoreState(s={}){promoters.clear();links.clear();coaching.length=0;earnings.length=0;withdrawals.length=0;for(const x of s.promoters||[])promoters.set(...x);for(const x of s.links||[])links.set(...x);coaching.push(...(s.coaching||[]));earnings.push(...(s.earnings||[]));withdrawals.push(...(s.withdrawals||[]));}

export function promoterDashboard(actorId,{bookings=[],runtimeDrivers=[],from=null,to=null}={}){
 const actor=promoters.get(actorId);if(!actor)return null;const ids=new Set(scopedDriverIds(actorId));
 const inRange=(x)=>{const d=new Date(x.createdAt||x.updatedAt||0);return (!from||d>=new Date(from))&&(!to||d<=new Date(to));};
 const scoped=bookings.filter(b=>ids.has(b.driverId)&&inRange(b));
 const statuses=(name)=>scoped.filter(b=>b.status===name).length;
 const requests=scoped.length,completed=statuses('COMPLETED'),cancelled=scoped.filter(b=>String(b.status).includes('CANCEL')).length;
 const rejected=scoped.reduce((n,b)=>n+(b.events||[]).filter(e=>String(e.type||e.event||'').includes('REJECT')).length,0);
 const accepted=Math.max(0,requests-rejected); const pct=(n,d)=>d?Number((n*100/d).toFixed(2)):0;
 const online=runtimeDrivers.filter(d=>ids.has(d.id||d.driverId)&&d.online).length;
 return {actor:sanitize(actor),scope:{driverCount:ids.size,onlineDrivers:online},period:{from,to},performance:{requests,accepted,rejected,cancelled,completed,acceptanceRate:pct(accepted,requests),rejectionRate:pct(rejected,requests),cancellationRate:pct(cancelled,requests)},earnings:earningsSummary(actorId)};
}
export function driverPerformanceRows(actorId,{bookings=[],runtimeDrivers=[],profiles=[],from=null,to=null}={}){const ids=scopedDriverIds(actorId);const range=b=>{const d=new Date(b.createdAt||b.updatedAt||0);return(!from||d>=new Date(from))&&(!to||d<=new Date(to));};return ids.map(id=>{const rows=bookings.filter(b=>b.driverId===id&&range(b));const rejected=rows.reduce((n,b)=>n+(b.events||[]).filter(e=>String(e.type||e.event||'').includes('REJECT')).length,0);const cancelled=rows.filter(b=>String(b.status).includes('CANCEL')).length;const completed=rows.filter(b=>b.status==='COMPLETED').length;const requests=rows.length;const accepted=Math.max(0,requests-rejected);const pct=(n,d)=>d?Number((n*100/d).toFixed(2)):0;const runtime=runtimeDrivers.find(d=>(d.id||d.driverId)===id);const profile=profiles.find(d=>d.id===id);return {driverId:id,name:profile?.fullName||profile?.name||'Driver',vehicleNumber:profile?.vehicle?.number||'',mobile:profile?.mobile||'',status:profile?.status||'DRAFT',approval:profile?.approval||null,verification:profile?.verification||null,partnerActions:profile?.partnerActions||null,online:Boolean(runtime?.online),lastOnlineAt:runtime?.updatedAt||null,requests,accepted,rejected,cancelled,completed,acceptanceRate:pct(accepted,requests),rejectionRate:pct(rejected,requests),cancellationRate:pct(cancelled,requests),rating:Number(profile?.rating||0)};});}
export function releaseMonthlyEarnings({month,beneficiaryId=null}){let count=0;for(const x of earnings){if(x.month===month&&(!beneficiaryId||x.beneficiaryId===beneficiaryId)&&x.status==='PENDING_MONTH_CLOSE'){x.status='WITHDRAWABLE';x.releasedAt=now();count++;}}return {month,beneficiaryId,count};}
export function requestPromoterWithdrawal(actorId,amount){const summary=earningsSummary(actorId);if(amount<=0||amount>summary.withdrawable)return {error:'settlement_not_open_or_insufficient_balance'};let remaining=amount;for(const row of earnings){if(row.beneficiaryId===actorId&&row.status==='WITHDRAWABLE'&&remaining>0){const used=Math.min(row.amount,remaining);row.amount=Number((row.amount-used).toFixed(2));remaining=Number((remaining-used).toFixed(2));}}const item={id:crypto.randomUUID(),beneficiaryId:actorId,amount,status:'REQUESTED',createdAt:now()};withdrawals.unshift(item);return clone(item);}
export function listPartnerWithdrawals(actorId){return withdrawals.filter(x=>x.beneficiaryId===actorId).map(clone);}
function sanitize(x){const y=clone(x);delete y.credential;delete y.password;return y;}
function nextMonthClose(){const d=new Date();return new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,1)).toISOString();}
